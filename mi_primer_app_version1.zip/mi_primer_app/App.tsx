//import { PositionScreen } from "./src/screens/PositionScreen";
//import { BoxObjectModelScreen } from "./src/screens/BoxObjectModelScreen";
//import { CounterScreen } from "./src/screens/CounterScreen";
//import { CounterReducerScreen } from "./src/screens/CounterReducerScreen";
//import { UseEffectScreen } from "./src/screens/UseEffectScreen";
import { StackNavigator } from "./src/navigator/StackNavigator";
import { PokemonNavigator } from "./src/navigator/PokemonNavigator";
import { NavigationContainer } from "@react-navigation/native";

const App = () => {

  return (
    //<CounterScreen/>
    //<CounterReducerScreen/>
    //<UseEffectScreen/>
    /*<NavigationContainer>
      <StackNavigator/>
    </NavigationContainer>*/
    <NavigationContainer>
      <PokemonNavigator/>
    </NavigationContainer>
  );

}

export default App;

/*import { View, Text } from "react-native";

let nombre: string = "Citlali ";

const App = () => {

  const grupo: string = "DSM-42";

  return (
    <View
      style={{
        alignItems: "center",
        alignContent: 'center'
      }}
    >
      <Text
        style={{
          marginTop: 400,
          fontSize: 50,
          color: 'black',
          textAlign: 'center'
        }}
      >
      </Text>
    </View>
  );

}

export default App;*/

